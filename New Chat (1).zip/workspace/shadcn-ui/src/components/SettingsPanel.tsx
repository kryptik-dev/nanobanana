import { Card, CardContent } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useState } from 'react';

const SettingsPanel = () => {
  const [autoScroll, setAutoScroll] = useState(true);
  const [markdownRendering, setMarkdownRendering] = useState(true);
  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(1000);

  return (
    <Card>
      <CardContent className="pt-4 space-y-6">
        {/* Temperature */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="temperature">Temperature: {temperature.toFixed(1)}</Label>
          </div>
          <Slider 
            id="temperature"
            min={0} 
            max={1} 
            step={0.1} 
            defaultValue={[temperature]}
            onValueChange={(value) => setTemperature(value[0])}
          />
          <p className="text-xs text-muted-foreground">
            Lower values make responses more focused and deterministic.
          </p>
        </div>

        {/* Max Tokens */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="max-tokens">Max Tokens: {maxTokens}</Label>
          </div>
          <Slider 
            id="max-tokens"
            min={100} 
            max={2000} 
            step={100}
            defaultValue={[maxTokens]}
            onValueChange={(value) => setMaxTokens(value[0])}
          />
          <p className="text-xs text-muted-foreground">
            Maximum number of tokens to generate in response.
          </p>
        </div>

        {/* Auto Scroll */}
        <div className="flex items-center justify-between">
          <Label htmlFor="auto-scroll" className="cursor-pointer">Auto Scroll</Label>
          <Switch
            id="auto-scroll"
            checked={autoScroll}
            onCheckedChange={setAutoScroll}
          />
        </div>

        {/* Markdown Rendering */}
        <div className="flex items-center justify-between">
          <Label htmlFor="markdown-rendering" className="cursor-pointer">Markdown Rendering</Label>
          <Switch
            id="markdown-rendering"
            checked={markdownRendering}
            onCheckedChange={setMarkdownRendering}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default SettingsPanel;