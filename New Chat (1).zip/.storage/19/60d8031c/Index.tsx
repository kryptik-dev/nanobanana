import { useEffect, useState } from 'react';
import Header from '@/components/Header';
import ChatInterface from '@/components/ChatInterface';
import ModelSelector from '@/components/ModelSelector';
import SettingsPanel from '@/components/SettingsPanel';
import { useChat } from '@/hooks/useChat';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { PanelRight, Settings } from 'lucide-react';

export default function Index() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isPuterLoaded, setIsPuterLoaded] = useState(false);
  const { messages, isProcessing, currentModel, setCurrentModel, sendMessage, streamingContent, resetChat } = useChat();

  // Check if Puter.js is loaded
  useEffect(() => {
    const checkPuterLoaded = setInterval(() => {
      if (window.puter) {
        setIsPuterLoaded(true);
        clearInterval(checkPuterLoaded);
      }
    }, 500);

    return () => clearInterval(checkPuterLoaded);
  }, []);

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* Header */}
      <Header resetChat={resetChat} />

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Mobile Menu Toggle Button */}
        <div className="md:hidden fixed bottom-4 right-4 z-50">
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button size="icon" variant="outline" className="rounded-full h-12 w-12 bg-primary text-primary-foreground hover:bg-primary/90">
                <PanelRight size={24} />
              </Button>
            </SheetTrigger>
            <SheetContent className="w-[280px] sm:w-[350px]">
              <div className="flex flex-col h-full pt-6 pb-4 space-y-6">
                <h3 className="text-lg font-medium">Models</h3>
                <ModelSelector currentModel={currentModel} setCurrentModel={setCurrentModel} />
                
                <div className="h-[1px] bg-border my-2"></div>
                
                <h3 className="text-lg font-medium">Settings</h3>
                <SettingsPanel />
              </div>
            </SheetContent>
          </Sheet>
        </div>

        {/* Chat Interface */}
        <div className="flex-1 overflow-hidden">
          <ChatInterface 
            messages={messages} 
            isProcessing={isProcessing} 
            sendMessage={sendMessage} 
            streamingContent={streamingContent}
            isPuterLoaded={isPuterLoaded}
          />
        </div>

        {/* Sidebar - Hidden on Mobile */}
        <div className="hidden md:flex md:w-[350px] border-l border-border flex-col p-4 space-y-6 overflow-auto">
          <div>
            <h3 className="text-lg font-medium mb-3">Models</h3>
            <ModelSelector currentModel={currentModel} setCurrentModel={setCurrentModel} />
          </div>

          <div className="h-[1px] bg-border my-2"></div>

          <div>
            <h3 className="text-lg font-medium mb-3">Settings</h3>
            <SettingsPanel />
          </div>
        </div>
      </div>
    </div>
  );
}