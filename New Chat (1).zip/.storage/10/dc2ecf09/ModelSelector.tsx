import { Card, CardContent } from '@/components/ui/card';
import { MODELS } from '@/lib/constants';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Model } from '@/lib/types';

interface ModelSelectorProps {
  currentModel: Model;
  setCurrentModel: (model: Model) => void;
}

const ModelSelector = ({ currentModel, setCurrentModel }: ModelSelectorProps) => {
  return (
    <Card>
      <CardContent className="pt-4">
        <RadioGroup 
          defaultValue={currentModel.id} 
          onValueChange={(value) => {
            const model = MODELS.find(m => m.id === value);
            if (model) setCurrentModel(model);
          }}
        >
          {MODELS.map((model) => (
            <div key={model.id} className="flex items-start space-x-2 mb-4">
              <RadioGroupItem value={model.id} id={model.id} />
              <div className="grid gap-1">
                <Label htmlFor={model.id} className="cursor-pointer font-medium">
                  {model.name}
                </Label>
                <p className="text-sm text-muted-foreground">
                  {model.description}
                </p>
              </div>
            </div>
          ))}
        </RadioGroup>
      </CardContent>
    </Card>
  );
};

export default ModelSelector;
