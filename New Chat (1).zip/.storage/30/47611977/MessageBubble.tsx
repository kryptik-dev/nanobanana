import ReactMarkdown from 'react-markdown';
import { Message } from '@/lib/types';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { User, Bot } from 'lucide-react';
import { cn } from '@/lib/utils';

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble = ({ message }: MessageBubbleProps) => {
  const isUser = message.role === 'user';

  return (
    <div 
      className={cn(
        "flex items-start gap-4 max-w-3xl mx-auto", 
        isUser ? "flex-row-reverse" : "flex-row"
      )}
    >
      {/* Avatar */}
      <Avatar className={cn(
        isUser ? "bg-primary" : "bg-indigo-500",
        "h-8 w-8"
      )}>
        {isUser ? (
          <AvatarFallback><User className="h-4 w-4 text-primary-foreground" /></AvatarFallback>
        ) : (
          <AvatarFallback><Bot className="h-4 w-4 text-white" /></AvatarFallback>
        )}
      </Avatar>

      {/* Message content */}
      <div 
        className={cn(
          "flex-1 px-4 py-2 overflow-hidden",
          isUser ? "text-primary-foreground" : "text-foreground"
        )}
      >
        <div className="font-medium mb-1">
          {isUser ? "You" : "Claude"}
        </div>
        {message.content && (
          <div className="prose dark:prose-invert prose-sm max-w-none">
            <ReactMarkdown>{message.content}</ReactMarkdown>
          </div>
        )}
      </div>
    </div>
  );
};

export default MessageBubble;