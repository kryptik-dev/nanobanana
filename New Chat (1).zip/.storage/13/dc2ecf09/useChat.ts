import { useState, useCallback, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Message, Model } from '@/lib/types';
import { MODELS } from '@/lib/constants';

declare global {
  interface Window {
    puter: any;
  }
}

export const useChat = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentModel, setCurrentModel] = useState<Model>(MODELS[0]);
  const [streamingContent, setStreamingContent] = useState('');

  // Send a message to the AI
  const sendMessage = useCallback(async (content: string) => {
    if (!window.puter) {
      console.error('PuterJS is not loaded');
      return;
    }

    // Create user message
    const userMessage: Message = {
      id: uuidv4(),
      content,
      role: 'user',
      createdAt: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsProcessing(true);
    setStreamingContent('');

    try {
      // Use streaming for real-time response
      const response = await window.puter.ai.chat(
        content,
        { model: currentModel.id, stream: true }
      );

      let fullResponse = '';

      for await (const part of response) {
        if (part?.text) {
          fullResponse += part.text;
          setStreamingContent(fullResponse);
        }
      }

      // Create AI message after streaming completes
      const aiMessage: Message = {
        id: uuidv4(),
        content: fullResponse,
        role: 'assistant',
        createdAt: new Date(),
      };

      setMessages((prev) => [...prev, aiMessage]);
      setStreamingContent('');
    } catch (error) {
      console.error('Error sending message:', error);
      // Handle error by creating an error message
      const errorMessage: Message = {
        id: uuidv4(),
        content: 'Sorry, there was an error processing your request. Please try again.',
        role: 'assistant',
        createdAt: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  }, [currentModel]);

  // Reset chat history
  const resetChat = useCallback(() => {
    setMessages([]);
    setStreamingContent('');
    setIsProcessing(false);
  }, []);

  // Save messages to localStorage when they change
  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem('ninjajs-messages', JSON.stringify(messages));
    }
  }, [messages]);

  // Load messages from localStorage on initial load
  useEffect(() => {
    const savedMessages = localStorage.getItem('ninjajs-messages');
    if (savedMessages) {
      try {
        const parsedMessages = JSON.parse(savedMessages);
        // Convert date strings to Date objects
        const messagesWithDates = parsedMessages.map((msg: any) => ({
          ...msg,
          createdAt: new Date(msg.createdAt),
        }));
        setMessages(messagesWithDates);
      } catch (error) {
        console.error('Error loading saved messages:', error);
      }
    }
  }, []);

  return {
    messages,
    isProcessing,
    currentModel,
    setCurrentModel,
    sendMessage,
    streamingContent,
    resetChat
  };
};
