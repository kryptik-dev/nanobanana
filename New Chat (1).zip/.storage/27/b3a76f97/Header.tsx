import { Button } from '@/components/ui/button';
import { ModeToggle } from '@/components/ui/theme-toggle';
import { Bot } from 'lucide-react';

interface HeaderProps {
  resetChat: () => void;
}

const Header = ({ resetChat }: HeaderProps) => {
  return (
    <header className="border-b border-border bg-background sticky top-0 z-10">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="h-6 w-6 text-indigo-500" />
          <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-500 to-purple-500 bg-clip-text text-transparent">
            NinjaJS
          </h1>
        </div>

        <div className="flex items-center gap-4">
          <Button 
            variant="ghost"
            size="sm" 
            onClick={resetChat}
          >
            New Chat
          </Button>
          <ModeToggle />
        </div>
      </div>
    </header>
  );
};

export default Header;