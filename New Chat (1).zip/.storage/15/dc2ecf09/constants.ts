import { Model } from './types';

// Available Claude models from PuterJS
export const MODELS: Model[] = [
  {
    id: 'claude-sonnet-4',
    name: 'Claude Sonnet 4',
    description: 'Optimal balance of intelligence and speed for most applications.',
    capabilities: ['Text generation', 'Reasoning', 'Creative writing']
  },
  {
    id: 'claude-opus-4',
    name: 'Claude Opus 4',
    description: 'Most intelligent model for complex tasks and reasoning.',
    capabilities: ['Advanced reasoning', 'Complex problem solving', 'Detailed content generation']
  },
  {
    id: 'claude-haiku-4',
    name: 'Claude Haiku 4',
    description: 'Fastest model with good capability for simple tasks.',
    capabilities: ['Fast responses', 'Simple queries', 'Basic assistance']
  }
];

// Default system message that can be expanded later
export const DEFAULT_SYSTEM_MESSAGE = 
  "You are Claude, a helpful AI assistant. You provide accurate, helpful responses and admit when you don't know something.";
