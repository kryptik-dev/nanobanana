import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { SendHorizontal, Bot } from 'lucide-react';
import MessageBubble from './MessageBubble';
import { Message } from '@/lib/types';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { InfoIcon } from 'lucide-react';

interface ChatInterfaceProps {
  messages: Message[];
  isProcessing: boolean;
  sendMessage: (content: string) => void;
  streamingContent: string;
  isPuterLoaded: boolean;
}

const ChatInterface = ({
  messages,
  isProcessing,
  sendMessage,
  streamingContent,
  isPuterLoaded
}: ChatInterfaceProps) => {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSend = () => {
    if (input.trim() && !isProcessing) {
      sendMessage(input.trim());
      setInput('');
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    // Auto-resize the textarea
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = `${textarea.scrollHeight}px`;
  };

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, streamingContent]);

  return (
    <div className="flex flex-col h-full bg-muted/40">
      {/* Welcome message if no messages */}
      {messages.length === 0 && (
        <div className="flex-1 overflow-auto p-4 flex items-center justify-center">
          <div className="max-w-md text-center space-y-6">
            <div className="flex justify-center">
              <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center">
                <Sparkles className="h-8 w-8 text-primary" />
              </div>
            </div>
            <h2 className="text-3xl font-semibold">Welcome to NinjaJS</h2>
            <p className="text-muted-foreground text-lg">
              Experience the power of Claude models for free. No API keys required.
            </p>
            {!isPuterLoaded && (
              <Alert variant="destructive" className="mt-4">
                <InfoIcon className="h-4 w-4" />
                <AlertDescription>
                  Loading PuterJS... Please wait
                </AlertDescription>
              </Alert>
            )}
          </div>
        </div>
      )}

      {/* Messages container */}
      {messages.length > 0 && (
        <div className="flex-1 overflow-auto py-6 px-4 md:px-8 space-y-6">
          {messages.map((message) => (
            <MessageBubble
              key={message.id}
              message={message}
            />
          ))}
          
          {/* Show streaming content */}
          {streamingContent && (
            <MessageBubble
              message={{
                id: 'streaming',
                content: streamingContent,
                role: 'assistant',
                createdAt: new Date(),
              }}
            />
          )}
          
          <div ref={messagesEndRef} />
        </div>
      )}

      {/* Input area */}
      <div className="border-t border-border p-4">
        <div className="relative flex items-end">
          <Textarea
            ref={textareaRef}
            placeholder={isPuterLoaded ? "Ask a question..." : "Loading PuterJS..."}
            value={input}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            className="pr-12 min-h-[60px] max-h-[200px] resize-none"
            disabled={isProcessing || !isPuterLoaded}
          />
          <Button
            size="icon"
            className="absolute right-2 bottom-2"
            onClick={handleSend}
            disabled={!input.trim() || isProcessing || !isPuterLoaded}
          >
            <SendHorizontal className="h-4 w-4" />
          </Button>
        </div>
        {isProcessing && (
          <div className="flex justify-center mt-2">
            <Badge variant="outline" className="animate-pulse">
              Processing...
            </Badge>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatInterface;