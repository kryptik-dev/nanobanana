// Message types for chat interaction
export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  createdAt: Date;
}

// Model interface for LLM models
export interface Model {
  id: string;
  name: string;
  description: string;
  capabilities: string[];
}
